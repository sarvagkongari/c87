# spectagram-stage-7
project solution for c87
